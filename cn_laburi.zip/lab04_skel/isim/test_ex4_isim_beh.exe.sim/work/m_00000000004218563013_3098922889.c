/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "state";
static const char *ng1 = "exp_output";
static const char *ng2 = "C:/Users/student/Desktop/lab04_skel/lib/helpers.vh";
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {170U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {85U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {4U, 0U};
static unsigned int ng9[] = {5U, 0U};
static unsigned int ng10[] = {129U, 0U};
static unsigned int ng11[] = {6U, 0U};
static unsigned int ng12[] = {66U, 0U};
static unsigned int ng13[] = {7U, 0U};
static unsigned int ng14[] = {36U, 0U};
static unsigned int ng15[] = {8U, 0U};
static unsigned int ng16[] = {24U, 0U};
static unsigned int ng17[] = {9U, 0U};
static unsigned int ng18[] = {10U, 0U};
static unsigned int ng19[] = {11U, 0U};
static unsigned int ng20[] = {12U, 0U};
static unsigned int ng21[] = {105U, 0U};
static unsigned int ng22[] = {13U, 0U};
static unsigned int ng23[] = {141U, 0U};
static unsigned int ng24[] = {14U, 0U};
static unsigned int ng25[] = {139U, 0U};
static unsigned int ng26[] = {15U, 0U};
static unsigned int ng27[] = {255U, 255U};
static const char *ng28 = "Total: %0d/%0d (%1.1Fp)";
static const char *ng29 = "The simulation is canceling...";
static int ng30[] = {0, 0};
static int ng31[] = {1, 0};
static const char *ng32 = "* ";
static const char *ng33 = "_ ";
static const char *ng34 = "C:/Users/student/Desktop/lab04_skel/test_ex4.v";
static const char *ng35 = "Expecting STATE_0 as current state after reset! - FAILED";
static int ng36[] = {4, 0};
static const char *ng37 = "Expecting STATE_1 as current state for 'G' input string! - FAILED";
static int ng38[] = {2, 0};
static const char *ng39 = "Expecting STATE_2 as current state for 'GG' input string! - FAILED";
static int ng40[] = {3, 0};
static const char *ng41 = "Expecting STATE_3 as current state for 'GGT' input string! - FAILED";
static const char *ng42 = "Mutant should be found for 'GGTC' input string! - FAILED";
static const char *ng43 = "Expecting STATE_4 as current state for 'GGTC' input string! - FAILED";



static void exp_output_varinit(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 96U);
    t2 = *((char **)t1);
    t3 = (t2 + 160U);
    t4 = (t0 + 80U);
    t5 = *((char **)t4);
    xsi_vlogvar_initialize(t3, ng0, 2, 3, 0, 0, t5, 0, 1, 0);
    t6 = (t0 + 96U);
    t7 = *((char **)t6);
    t8 = (t7 + 0U);
    t9 = (t0 + 80U);
    t10 = *((char **)t9);
    xsi_vlogvar_initialize(t8, ng1, 2, 7, 0, 0, t10, 0, 1, 0);

LAB1:    return;
}

static int sp_exp_output(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    t0 = 1;
    xsi_set_current_line(3, ng2);

LAB2:    xsi_set_current_line(4, ng2);
    t3 = (t2 + 96U);
    t4 = *((char **)t3);
    t5 = (t4 + 160U);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);

LAB3:    t8 = ((char*)((ng3)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t8, 4);
    if (t9 == 1)
        goto LAB4;

LAB5:    t3 = ((char*)((ng5)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB6;

LAB7:    t3 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB8;

LAB9:    t3 = ((char*)((ng8)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB10;

LAB11:    t3 = ((char*)((ng9)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB12;

LAB13:    t3 = ((char*)((ng11)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB14;

LAB15:    t3 = ((char*)((ng13)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB16;

LAB17:    t3 = ((char*)((ng15)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB18;

LAB19:    t3 = ((char*)((ng17)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB20;

LAB21:    t3 = ((char*)((ng18)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB22;

LAB23:    t3 = ((char*)((ng19)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB24;

LAB25:    t3 = ((char*)((ng20)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB26;

LAB27:    t3 = ((char*)((ng22)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB28;

LAB29:    t3 = ((char*)((ng24)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB30;

LAB31:    t3 = ((char*)((ng26)));
    t9 = xsi_vlog_unsigned_case_compare(t7, 4, t3, 4);
    if (t9 == 1)
        goto LAB32;

LAB33:
LAB35:
LAB34:    xsi_set_current_line(20, ng2);
    t3 = ((char*)((ng27)));
    t4 = (t2 + 96U);
    t5 = *((char **)t4);
    t6 = (t5 + 0U);
    xsi_vlogvar_assign_value(t6, t3, 0, 0, 8);

LAB36:    t0 = 0;

LAB1:    return t0;
LAB4:    xsi_set_current_line(5, ng2);
    t10 = ((char*)((ng4)));
    t11 = (t2 + 96U);
    t12 = *((char **)t11);
    t13 = (t12 + 0U);
    xsi_vlogvar_assign_value(t13, t10, 0, 0, 8);
    goto LAB36;

LAB6:    xsi_set_current_line(6, ng2);
    t4 = ((char*)((ng6)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB8:    xsi_set_current_line(7, ng2);
    t4 = ((char*)((ng4)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB10:    xsi_set_current_line(8, ng2);
    t4 = ((char*)((ng6)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB12:    xsi_set_current_line(9, ng2);
    t4 = ((char*)((ng10)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB14:    xsi_set_current_line(10, ng2);
    t4 = ((char*)((ng12)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB16:    xsi_set_current_line(11, ng2);
    t4 = ((char*)((ng14)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB18:    xsi_set_current_line(12, ng2);
    t4 = ((char*)((ng16)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB20:    xsi_set_current_line(13, ng2);
    t4 = ((char*)((ng14)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB22:    xsi_set_current_line(14, ng2);
    t4 = ((char*)((ng12)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB24:    xsi_set_current_line(15, ng2);
    t4 = ((char*)((ng10)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB26:    xsi_set_current_line(16, ng2);
    t4 = ((char*)((ng21)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB28:    xsi_set_current_line(17, ng2);
    t4 = ((char*)((ng23)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB30:    xsi_set_current_line(18, ng2);
    t4 = ((char*)((ng25)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

LAB32:    xsi_set_current_line(19, ng2);
    t4 = ((char*)((ng21)));
    t5 = (t2 + 96U);
    t6 = *((char **)t5);
    t8 = (t6 + 0U);
    xsi_vlogvar_assign_value(t8, t4, 0, 0, 8);
    goto LAB36;

}

static int sp_succ_exit(char *t1, char *t2)
{
    char t23[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    double t12;
    char *t13;
    char *t14;
    char *t15;
    double t16;
    double t17;
    char *t18;
    char *t19;
    char *t20;
    double t21;
    double t22;
    char *t24;

LAB0:    t0 = 1;
    xsi_set_current_line(29, ng2);

LAB2:    xsi_set_current_line(30, ng2);
    t3 = (t1 + 4776);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 4936);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 4776);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = xsi_vlog_convert_to_real(t11, 8, 2);
    t13 = (t1 + 5096);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = *((double *)t15);
    t17 = (t12 * t16);
    t18 = (t1 + 4936);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = xsi_vlog_convert_to_real(t20, 8, 2);
    t22 = (t17 / t21);
    *((double *)t23) = t22;
    t24 = (t1 + 1280);
    xsi_vlogfile_write(1, 0, 0, ng28, 4, t24, (char)118, t5, 8, (char)118, t8, 8, (char)114, t23, 64);
    xsi_set_current_line(31, ng2);
    xsi_vlog_stop(1);
    t0 = 0;

LAB1:    return t0;
}

static int sp_err_exit(char *t1, char *t2)
{
    char t23[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    double t12;
    char *t13;
    char *t14;
    char *t15;
    double t16;
    double t17;
    char *t18;
    char *t19;
    char *t20;
    double t21;
    double t22;
    char *t24;

LAB0:    t0 = 1;
    xsi_set_current_line(39, ng2);

LAB2:    xsi_set_current_line(40, ng2);
    t3 = (t1 + 1712);
    xsi_vlogfile_write(1, 0, 0, ng29, 1, t3);
    xsi_set_current_line(41, ng2);
    t3 = (t1 + 5416);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 5576);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 5416);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = xsi_vlog_convert_to_real(t11, 8, 2);
    t13 = (t1 + 5736);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = *((double *)t15);
    t17 = (t12 * t16);
    t18 = (t1 + 5576);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = xsi_vlog_convert_to_real(t20, 8, 2);
    t22 = (t17 / t21);
    *((double *)t23) = t22;
    t24 = (t1 + 1712);
    xsi_vlogfile_write(1, 0, 0, ng28, 4, t24, (char)118, t5, 8, (char)118, t8, 8, (char)114, t23, 64);
    xsi_set_current_line(42, ng2);
    xsi_vlog_stop(1);
    t0 = 0;

LAB1:    return t0;
}

static int sp_show_LEDs(char *t1, char *t2)
{
    char t7[8];
    char t20[8];
    char t28[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;

LAB0:    t0 = 1;
    xsi_set_current_line(50, ng2);

LAB2:    xsi_set_current_line(51, ng2);
    xsi_set_current_line(51, ng2);
    t3 = (t1 + 6216);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 6376);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 6);

LAB3:    t3 = (t1 + 6376);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng30)));
    memset(t7, 0, 8);
    t8 = (t5 + 4);
    if (*((unsigned int *)t8) != 0)
        goto LAB5;

LAB4:    t9 = (t6 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB5;

LAB8:    if (*((unsigned int *)t5) > *((unsigned int *)t6))
        goto LAB6;

LAB7:    t11 = (t7 + 4);
    t12 = *((unsigned int *)t11);
    t13 = (~(t12));
    t14 = *((unsigned int *)t7);
    t15 = (t14 & t13);
    t16 = (t15 != 0);
    if (t16 > 0)
        goto LAB9;

LAB10:    t0 = 0;

LAB1:    return t0;
LAB5:    t10 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB7;

LAB6:    *((unsigned int *)t7) = 1;
    goto LAB7;

LAB9:    xsi_set_current_line(51, ng2);

LAB11:    xsi_set_current_line(52, ng2);
    t17 = (t1 + 6056);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t21 = (t1 + 6056);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t1 + 6376);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = ((char*)((ng31)));
    memset(t28, 0, 8);
    xsi_vlog_unsigned_minus(t28, 32, t26, 6, t27, 32);
    xsi_vlog_generic_get_index_select_value(t20, 1, t19, t23, 2, t28, 32, 2);
    t29 = (t20 + 4);
    t30 = *((unsigned int *)t29);
    t31 = (~(t30));
    t32 = *((unsigned int *)t20);
    t33 = (t32 & t31);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB12;

LAB13:    xsi_set_current_line(55, ng2);
    t3 = (t1 + 2144);
    xsi_vlogfile_write(0, 0, 1, ng33, 1, t3);

LAB14:    xsi_set_current_line(51, ng2);
    t3 = (t1 + 6376);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng31)));
    memset(t7, 0, 8);
    xsi_vlog_unsigned_minus(t7, 32, t5, 6, t6, 32);
    t8 = (t1 + 6376);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 6);
    goto LAB3;

LAB12:    xsi_set_current_line(53, ng2);
    t35 = (t1 + 2144);
    xsi_vlogfile_write(0, 0, 1, ng32, 1, t35);
    goto LAB14;

}

static void Initial_36_0(char *t0)
{
    char t5[8];
    char t21[8];
    char t35[8];
    char t51[8];
    char t59[8];
    char t101[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    char *t64;
    char *t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    char *t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    int t83;
    int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t102;
    double t103;

LAB0:    t1 = (t0 + 7296U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng34);

LAB4:    xsi_set_current_line(38, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(39, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(40, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(41, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(42, ng34);
    t2 = ((char*)((ng31)));
    t3 = (t0 + 4136);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(43, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 4296);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(46, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 4456);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);
    xsi_set_current_line(49, ng34);
    t2 = (t0 + 7104);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(50, ng34);
    t3 = (t0 + 2776U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng30)));
    memset(t5, 0, 8);
    t6 = (t4 + 4);
    t7 = (t3 + 4);
    t8 = *((unsigned int *)t4);
    t9 = *((unsigned int *)t3);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    t14 = (t10 | t13);
    t15 = *((unsigned int *)t6);
    t16 = *((unsigned int *)t7);
    t17 = (t15 | t16);
    t18 = (~(t17));
    t19 = (t14 & t18);
    if (t19 != 0)
        goto LAB9;

LAB6:    if (t17 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t5) = 1;

LAB9:    memset(t21, 0, 8);
    t22 = (t5 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t5);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t22) != 0)
        goto LAB12;

LAB13:    t29 = (t21 + 4);
    t30 = *((unsigned int *)t21);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB14;

LAB15:    memcpy(t59, t21, 8);

LAB16:    t91 = (t59 + 4);
    t92 = *((unsigned int *)t91);
    t93 = (~(t92));
    t94 = *((unsigned int *)t59);
    t95 = (t94 & t93);
    t96 = (t95 != 0);
    if (t96 > 0)
        goto LAB28;

LAB29:    xsi_set_current_line(52, ng34);

LAB31:    xsi_set_current_line(53, ng34);
    xsi_vlogfile_write(1, 0, 0, ng35, 1, t0);
    xsi_set_current_line(54, ng34);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng11)));
    t7 = ((char*)((ng36)));
    t20 = (t0 + 7104);
    t22 = (t0 + 1712);
    t28 = xsi_create_subprogram_invocation(t20, 0, t0, t22, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t22, t28);
    t29 = (t0 + 5416);
    xsi_vlogvar_assign_value(t29, t5, 0, 0, 8);
    t33 = (t0 + 5576);
    xsi_vlogvar_assign_value(t33, t6, 0, 0, 8);
    t34 = (t0 + 5736);
    t36 = ((char*)((ng36)));
    t103 = xsi_vlog_convert_to_real(t36, 32, 1);
    xsi_vlogvar_assign_value_double(t34, t103, 0);

LAB34:    t37 = (t0 + 7200);
    t50 = *((char **)t37);
    t52 = (t50 + 80U);
    t58 = *((char **)t52);
    t63 = (t58 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t73 = *((char **)t65);
    t83 = ((int  (*)(char *, char *))t73)(t0, t50);

LAB36:    if (t83 != 0)
        goto LAB37;

LAB32:    t50 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t50);

LAB33:    t74 = (t0 + 7200);
    t91 = *((char **)t74);
    t74 = (t0 + 1712);
    t97 = (t0 + 7104);
    t98 = 0;
    xsi_delete_subprogram_invocation(t74, t91, t0, t97, t98);

LAB30:    xsi_set_current_line(56, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 4136);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(58, ng34);
    t2 = ((char*)((ng31)));
    t3 = (t0 + 3656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(59, ng34);
    t2 = (t0 + 7104);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB38;
    goto LAB1;

LAB8:    t20 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB9;

LAB10:    *((unsigned int *)t21) = 1;
    goto LAB13;

LAB12:    t28 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB13;

LAB14:    t33 = (t0 + 3096U);
    t34 = *((char **)t33);
    t33 = ((char*)((ng30)));
    memset(t35, 0, 8);
    t36 = (t34 + 4);
    t37 = (t33 + 4);
    t38 = *((unsigned int *)t34);
    t39 = *((unsigned int *)t33);
    t40 = (t38 ^ t39);
    t41 = *((unsigned int *)t36);
    t42 = *((unsigned int *)t37);
    t43 = (t41 ^ t42);
    t44 = (t40 | t43);
    t45 = *((unsigned int *)t36);
    t46 = *((unsigned int *)t37);
    t47 = (t45 | t46);
    t48 = (~(t47));
    t49 = (t44 & t48);
    if (t49 != 0)
        goto LAB20;

LAB17:    if (t47 != 0)
        goto LAB19;

LAB18:    *((unsigned int *)t35) = 1;

LAB20:    memset(t51, 0, 8);
    t52 = (t35 + 4);
    t53 = *((unsigned int *)t52);
    t54 = (~(t53));
    t55 = *((unsigned int *)t35);
    t56 = (t55 & t54);
    t57 = (t56 & 1U);
    if (t57 != 0)
        goto LAB21;

LAB22:    if (*((unsigned int *)t52) != 0)
        goto LAB23;

LAB24:    t60 = *((unsigned int *)t21);
    t61 = *((unsigned int *)t51);
    t62 = (t60 & t61);
    *((unsigned int *)t59) = t62;
    t63 = (t21 + 4);
    t64 = (t51 + 4);
    t65 = (t59 + 4);
    t66 = *((unsigned int *)t63);
    t67 = *((unsigned int *)t64);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t69 = *((unsigned int *)t65);
    t70 = (t69 != 0);
    if (t70 == 1)
        goto LAB25;

LAB26:
LAB27:    goto LAB16;

LAB19:    t50 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t50) = 1;
    goto LAB20;

LAB21:    *((unsigned int *)t51) = 1;
    goto LAB24;

LAB23:    t58 = (t51 + 4);
    *((unsigned int *)t51) = 1;
    *((unsigned int *)t58) = 1;
    goto LAB24;

LAB25:    t71 = *((unsigned int *)t59);
    t72 = *((unsigned int *)t65);
    *((unsigned int *)t59) = (t71 | t72);
    t73 = (t21 + 4);
    t74 = (t51 + 4);
    t75 = *((unsigned int *)t21);
    t76 = (~(t75));
    t77 = *((unsigned int *)t73);
    t78 = (~(t77));
    t79 = *((unsigned int *)t51);
    t80 = (~(t79));
    t81 = *((unsigned int *)t74);
    t82 = (~(t81));
    t83 = (t76 & t78);
    t84 = (t80 & t82);
    t85 = (~(t83));
    t86 = (~(t84));
    t87 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t87 & t85);
    t88 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t88 & t86);
    t89 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t89 & t85);
    t90 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t90 & t86);
    goto LAB27;

LAB28:    xsi_set_current_line(51, ng34);
    t97 = (t0 + 4456);
    t98 = (t97 + 56U);
    t99 = *((char **)t98);
    t100 = ((char*)((ng31)));
    memset(t101, 0, 8);
    xsi_vlog_unsigned_add(t101, 32, t99, 5, t100, 32);
    t102 = (t0 + 4456);
    xsi_vlogvar_assign_value(t102, t101, 0, 0, 5);
    goto LAB30;

LAB35:;
LAB37:    t37 = (t0 + 7296U);
    *((char **)t37) = &&LAB34;
    goto LAB1;

LAB38:    xsi_set_current_line(60, ng34);
    t3 = (t0 + 2776U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng30)));
    memset(t5, 0, 8);
    t6 = (t4 + 4);
    t7 = (t3 + 4);
    t8 = *((unsigned int *)t4);
    t9 = *((unsigned int *)t3);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    t14 = (t10 | t13);
    t15 = *((unsigned int *)t6);
    t16 = *((unsigned int *)t7);
    t17 = (t15 | t16);
    t18 = (~(t17));
    t19 = (t14 & t18);
    if (t19 != 0)
        goto LAB42;

LAB39:    if (t17 != 0)
        goto LAB41;

LAB40:    *((unsigned int *)t5) = 1;

LAB42:    memset(t21, 0, 8);
    t22 = (t5 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t5);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t22) != 0)
        goto LAB45;

LAB46:    t29 = (t21 + 4);
    t30 = *((unsigned int *)t21);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB47;

LAB48:    memcpy(t59, t21, 8);

LAB49:    t91 = (t59 + 4);
    t92 = *((unsigned int *)t91);
    t93 = (~(t92));
    t94 = *((unsigned int *)t59);
    t95 = (t94 & t93);
    t96 = (t95 != 0);
    if (t96 > 0)
        goto LAB61;

LAB62:    xsi_set_current_line(62, ng34);

LAB64:    xsi_set_current_line(63, ng34);
    xsi_vlogfile_write(1, 0, 0, ng37, 1, t0);
    xsi_set_current_line(64, ng34);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng11)));
    t7 = ((char*)((ng36)));
    t20 = (t0 + 7104);
    t22 = (t0 + 1712);
    t28 = xsi_create_subprogram_invocation(t20, 0, t0, t22, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t22, t28);
    t29 = (t0 + 5416);
    xsi_vlogvar_assign_value(t29, t5, 0, 0, 8);
    t33 = (t0 + 5576);
    xsi_vlogvar_assign_value(t33, t6, 0, 0, 8);
    t34 = (t0 + 5736);
    t36 = ((char*)((ng36)));
    t103 = xsi_vlog_convert_to_real(t36, 32, 1);
    xsi_vlogvar_assign_value_double(t34, t103, 0);

LAB67:    t37 = (t0 + 7200);
    t50 = *((char **)t37);
    t52 = (t50 + 80U);
    t58 = *((char **)t52);
    t63 = (t58 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t73 = *((char **)t65);
    t83 = ((int  (*)(char *, char *))t73)(t0, t50);

LAB69:    if (t83 != 0)
        goto LAB70;

LAB65:    t50 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t50);

LAB66:    t74 = (t0 + 7200);
    t91 = *((char **)t74);
    t74 = (t0 + 1712);
    t97 = (t0 + 7104);
    t98 = 0;
    xsi_delete_subprogram_invocation(t74, t91, t0, t97, t98);

LAB63:    xsi_set_current_line(67, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(68, ng34);
    t2 = (t0 + 7104);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB71;
    goto LAB1;

LAB41:    t20 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB42;

LAB43:    *((unsigned int *)t21) = 1;
    goto LAB46;

LAB45:    t28 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB46;

LAB47:    t33 = (t0 + 3096U);
    t34 = *((char **)t33);
    t33 = ((char*)((ng31)));
    memset(t35, 0, 8);
    t36 = (t34 + 4);
    t37 = (t33 + 4);
    t38 = *((unsigned int *)t34);
    t39 = *((unsigned int *)t33);
    t40 = (t38 ^ t39);
    t41 = *((unsigned int *)t36);
    t42 = *((unsigned int *)t37);
    t43 = (t41 ^ t42);
    t44 = (t40 | t43);
    t45 = *((unsigned int *)t36);
    t46 = *((unsigned int *)t37);
    t47 = (t45 | t46);
    t48 = (~(t47));
    t49 = (t44 & t48);
    if (t49 != 0)
        goto LAB53;

LAB50:    if (t47 != 0)
        goto LAB52;

LAB51:    *((unsigned int *)t35) = 1;

LAB53:    memset(t51, 0, 8);
    t52 = (t35 + 4);
    t53 = *((unsigned int *)t52);
    t54 = (~(t53));
    t55 = *((unsigned int *)t35);
    t56 = (t55 & t54);
    t57 = (t56 & 1U);
    if (t57 != 0)
        goto LAB54;

LAB55:    if (*((unsigned int *)t52) != 0)
        goto LAB56;

LAB57:    t60 = *((unsigned int *)t21);
    t61 = *((unsigned int *)t51);
    t62 = (t60 & t61);
    *((unsigned int *)t59) = t62;
    t63 = (t21 + 4);
    t64 = (t51 + 4);
    t65 = (t59 + 4);
    t66 = *((unsigned int *)t63);
    t67 = *((unsigned int *)t64);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t69 = *((unsigned int *)t65);
    t70 = (t69 != 0);
    if (t70 == 1)
        goto LAB58;

LAB59:
LAB60:    goto LAB49;

LAB52:    t50 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t50) = 1;
    goto LAB53;

LAB54:    *((unsigned int *)t51) = 1;
    goto LAB57;

LAB56:    t58 = (t51 + 4);
    *((unsigned int *)t51) = 1;
    *((unsigned int *)t58) = 1;
    goto LAB57;

LAB58:    t71 = *((unsigned int *)t59);
    t72 = *((unsigned int *)t65);
    *((unsigned int *)t59) = (t71 | t72);
    t73 = (t21 + 4);
    t74 = (t51 + 4);
    t75 = *((unsigned int *)t21);
    t76 = (~(t75));
    t77 = *((unsigned int *)t73);
    t78 = (~(t77));
    t79 = *((unsigned int *)t51);
    t80 = (~(t79));
    t81 = *((unsigned int *)t74);
    t82 = (~(t81));
    t83 = (t76 & t78);
    t84 = (t80 & t82);
    t85 = (~(t83));
    t86 = (~(t84));
    t87 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t87 & t85);
    t88 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t88 & t86);
    t89 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t89 & t85);
    t90 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t90 & t86);
    goto LAB60;

LAB61:    xsi_set_current_line(61, ng34);
    t97 = (t0 + 4456);
    t98 = (t97 + 56U);
    t99 = *((char **)t98);
    t100 = ((char*)((ng31)));
    memset(t101, 0, 8);
    xsi_vlog_unsigned_add(t101, 32, t99, 5, t100, 32);
    t102 = (t0 + 4456);
    xsi_vlogvar_assign_value(t102, t101, 0, 0, 5);
    goto LAB63;

LAB68:;
LAB70:    t37 = (t0 + 7296U);
    *((char **)t37) = &&LAB67;
    goto LAB1;

LAB71:    xsi_set_current_line(70, ng34);
    t3 = ((char*)((ng31)));
    t4 = (t0 + 3656);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(71, ng34);
    t2 = (t0 + 7104);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB72;
    goto LAB1;

LAB72:    xsi_set_current_line(72, ng34);
    t3 = (t0 + 2776U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng30)));
    memset(t5, 0, 8);
    t6 = (t4 + 4);
    t7 = (t3 + 4);
    t8 = *((unsigned int *)t4);
    t9 = *((unsigned int *)t3);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    t14 = (t10 | t13);
    t15 = *((unsigned int *)t6);
    t16 = *((unsigned int *)t7);
    t17 = (t15 | t16);
    t18 = (~(t17));
    t19 = (t14 & t18);
    if (t19 != 0)
        goto LAB76;

LAB73:    if (t17 != 0)
        goto LAB75;

LAB74:    *((unsigned int *)t5) = 1;

LAB76:    memset(t21, 0, 8);
    t22 = (t5 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t5);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB77;

LAB78:    if (*((unsigned int *)t22) != 0)
        goto LAB79;

LAB80:    t29 = (t21 + 4);
    t30 = *((unsigned int *)t21);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB81;

LAB82:    memcpy(t59, t21, 8);

LAB83:    t91 = (t59 + 4);
    t92 = *((unsigned int *)t91);
    t93 = (~(t92));
    t94 = *((unsigned int *)t59);
    t95 = (t94 & t93);
    t96 = (t95 != 0);
    if (t96 > 0)
        goto LAB95;

LAB96:    xsi_set_current_line(74, ng34);

LAB98:    xsi_set_current_line(75, ng34);
    xsi_vlogfile_write(1, 0, 0, ng39, 1, t0);
    xsi_set_current_line(76, ng34);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng11)));
    t7 = ((char*)((ng36)));
    t20 = (t0 + 7104);
    t22 = (t0 + 1712);
    t28 = xsi_create_subprogram_invocation(t20, 0, t0, t22, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t22, t28);
    t29 = (t0 + 5416);
    xsi_vlogvar_assign_value(t29, t5, 0, 0, 8);
    t33 = (t0 + 5576);
    xsi_vlogvar_assign_value(t33, t6, 0, 0, 8);
    t34 = (t0 + 5736);
    t36 = ((char*)((ng36)));
    t103 = xsi_vlog_convert_to_real(t36, 32, 1);
    xsi_vlogvar_assign_value_double(t34, t103, 0);

LAB101:    t37 = (t0 + 7200);
    t50 = *((char **)t37);
    t52 = (t50 + 80U);
    t58 = *((char **)t52);
    t63 = (t58 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t73 = *((char **)t65);
    t83 = ((int  (*)(char *, char *))t73)(t0, t50);

LAB103:    if (t83 != 0)
        goto LAB104;

LAB99:    t50 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t50);

LAB100:    t74 = (t0 + 7200);
    t91 = *((char **)t74);
    t74 = (t0 + 1712);
    t97 = (t0 + 7104);
    t98 = 0;
    xsi_delete_subprogram_invocation(t74, t91, t0, t97, t98);

LAB97:    xsi_set_current_line(79, ng34);
    t2 = ((char*)((ng31)));
    t3 = (t0 + 3976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(80, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3656);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(81, ng34);
    t2 = (t0 + 7104);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB105;
    goto LAB1;

LAB75:    t20 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB76;

LAB77:    *((unsigned int *)t21) = 1;
    goto LAB80;

LAB79:    t28 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB80;

LAB81:    t33 = (t0 + 3096U);
    t34 = *((char **)t33);
    t33 = ((char*)((ng38)));
    memset(t35, 0, 8);
    t36 = (t34 + 4);
    t37 = (t33 + 4);
    t38 = *((unsigned int *)t34);
    t39 = *((unsigned int *)t33);
    t40 = (t38 ^ t39);
    t41 = *((unsigned int *)t36);
    t42 = *((unsigned int *)t37);
    t43 = (t41 ^ t42);
    t44 = (t40 | t43);
    t45 = *((unsigned int *)t36);
    t46 = *((unsigned int *)t37);
    t47 = (t45 | t46);
    t48 = (~(t47));
    t49 = (t44 & t48);
    if (t49 != 0)
        goto LAB87;

LAB84:    if (t47 != 0)
        goto LAB86;

LAB85:    *((unsigned int *)t35) = 1;

LAB87:    memset(t51, 0, 8);
    t52 = (t35 + 4);
    t53 = *((unsigned int *)t52);
    t54 = (~(t53));
    t55 = *((unsigned int *)t35);
    t56 = (t55 & t54);
    t57 = (t56 & 1U);
    if (t57 != 0)
        goto LAB88;

LAB89:    if (*((unsigned int *)t52) != 0)
        goto LAB90;

LAB91:    t60 = *((unsigned int *)t21);
    t61 = *((unsigned int *)t51);
    t62 = (t60 & t61);
    *((unsigned int *)t59) = t62;
    t63 = (t21 + 4);
    t64 = (t51 + 4);
    t65 = (t59 + 4);
    t66 = *((unsigned int *)t63);
    t67 = *((unsigned int *)t64);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t69 = *((unsigned int *)t65);
    t70 = (t69 != 0);
    if (t70 == 1)
        goto LAB92;

LAB93:
LAB94:    goto LAB83;

LAB86:    t50 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t50) = 1;
    goto LAB87;

LAB88:    *((unsigned int *)t51) = 1;
    goto LAB91;

LAB90:    t58 = (t51 + 4);
    *((unsigned int *)t51) = 1;
    *((unsigned int *)t58) = 1;
    goto LAB91;

LAB92:    t71 = *((unsigned int *)t59);
    t72 = *((unsigned int *)t65);
    *((unsigned int *)t59) = (t71 | t72);
    t73 = (t21 + 4);
    t74 = (t51 + 4);
    t75 = *((unsigned int *)t21);
    t76 = (~(t75));
    t77 = *((unsigned int *)t73);
    t78 = (~(t77));
    t79 = *((unsigned int *)t51);
    t80 = (~(t79));
    t81 = *((unsigned int *)t74);
    t82 = (~(t81));
    t83 = (t76 & t78);
    t84 = (t80 & t82);
    t85 = (~(t83));
    t86 = (~(t84));
    t87 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t87 & t85);
    t88 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t88 & t86);
    t89 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t89 & t85);
    t90 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t90 & t86);
    goto LAB94;

LAB95:    xsi_set_current_line(73, ng34);
    t97 = (t0 + 4456);
    t98 = (t97 + 56U);
    t99 = *((char **)t98);
    t100 = ((char*)((ng31)));
    memset(t101, 0, 8);
    xsi_vlog_unsigned_add(t101, 32, t99, 5, t100, 32);
    t102 = (t0 + 4456);
    xsi_vlogvar_assign_value(t102, t101, 0, 0, 5);
    goto LAB97;

LAB102:;
LAB104:    t37 = (t0 + 7296U);
    *((char **)t37) = &&LAB101;
    goto LAB1;

LAB105:    xsi_set_current_line(82, ng34);
    t3 = (t0 + 2776U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng30)));
    memset(t5, 0, 8);
    t6 = (t4 + 4);
    t7 = (t3 + 4);
    t8 = *((unsigned int *)t4);
    t9 = *((unsigned int *)t3);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    t14 = (t10 | t13);
    t15 = *((unsigned int *)t6);
    t16 = *((unsigned int *)t7);
    t17 = (t15 | t16);
    t18 = (~(t17));
    t19 = (t14 & t18);
    if (t19 != 0)
        goto LAB109;

LAB106:    if (t17 != 0)
        goto LAB108;

LAB107:    *((unsigned int *)t5) = 1;

LAB109:    memset(t21, 0, 8);
    t22 = (t5 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t5);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB110;

LAB111:    if (*((unsigned int *)t22) != 0)
        goto LAB112;

LAB113:    t29 = (t21 + 4);
    t30 = *((unsigned int *)t21);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB114;

LAB115:    memcpy(t59, t21, 8);

LAB116:    t91 = (t59 + 4);
    t92 = *((unsigned int *)t91);
    t93 = (~(t92));
    t94 = *((unsigned int *)t59);
    t95 = (t94 & t93);
    t96 = (t95 != 0);
    if (t96 > 0)
        goto LAB128;

LAB129:    xsi_set_current_line(84, ng34);

LAB131:    xsi_set_current_line(85, ng34);
    xsi_vlogfile_write(1, 0, 0, ng41, 1, t0);
    xsi_set_current_line(86, ng34);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng11)));
    t7 = ((char*)((ng36)));
    t20 = (t0 + 7104);
    t22 = (t0 + 1712);
    t28 = xsi_create_subprogram_invocation(t20, 0, t0, t22, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t22, t28);
    t29 = (t0 + 5416);
    xsi_vlogvar_assign_value(t29, t5, 0, 0, 8);
    t33 = (t0 + 5576);
    xsi_vlogvar_assign_value(t33, t6, 0, 0, 8);
    t34 = (t0 + 5736);
    t36 = ((char*)((ng36)));
    t103 = xsi_vlog_convert_to_real(t36, 32, 1);
    xsi_vlogvar_assign_value_double(t34, t103, 0);

LAB134:    t37 = (t0 + 7200);
    t50 = *((char **)t37);
    t52 = (t50 + 80U);
    t58 = *((char **)t52);
    t63 = (t58 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t73 = *((char **)t65);
    t83 = ((int  (*)(char *, char *))t73)(t0, t50);

LAB136:    if (t83 != 0)
        goto LAB137;

LAB132:    t50 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t50);

LAB133:    t74 = (t0 + 7200);
    t91 = *((char **)t74);
    t74 = (t0 + 1712);
    t97 = (t0 + 7104);
    t98 = 0;
    xsi_delete_subprogram_invocation(t74, t91, t0, t97, t98);

LAB130:    xsi_set_current_line(89, ng34);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 3976);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(90, ng34);
    t2 = ((char*)((ng31)));
    t3 = (t0 + 3816);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(91, ng34);
    t2 = (t0 + 7104);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB138;
    goto LAB1;

LAB108:    t20 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t20) = 1;
    goto LAB109;

LAB110:    *((unsigned int *)t21) = 1;
    goto LAB113;

LAB112:    t28 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB113;

LAB114:    t33 = (t0 + 3096U);
    t34 = *((char **)t33);
    t33 = ((char*)((ng40)));
    memset(t35, 0, 8);
    t36 = (t34 + 4);
    t37 = (t33 + 4);
    t38 = *((unsigned int *)t34);
    t39 = *((unsigned int *)t33);
    t40 = (t38 ^ t39);
    t41 = *((unsigned int *)t36);
    t42 = *((unsigned int *)t37);
    t43 = (t41 ^ t42);
    t44 = (t40 | t43);
    t45 = *((unsigned int *)t36);
    t46 = *((unsigned int *)t37);
    t47 = (t45 | t46);
    t48 = (~(t47));
    t49 = (t44 & t48);
    if (t49 != 0)
        goto LAB120;

LAB117:    if (t47 != 0)
        goto LAB119;

LAB118:    *((unsigned int *)t35) = 1;

LAB120:    memset(t51, 0, 8);
    t52 = (t35 + 4);
    t53 = *((unsigned int *)t52);
    t54 = (~(t53));
    t55 = *((unsigned int *)t35);
    t56 = (t55 & t54);
    t57 = (t56 & 1U);
    if (t57 != 0)
        goto LAB121;

LAB122:    if (*((unsigned int *)t52) != 0)
        goto LAB123;

LAB124:    t60 = *((unsigned int *)t21);
    t61 = *((unsigned int *)t51);
    t62 = (t60 & t61);
    *((unsigned int *)t59) = t62;
    t63 = (t21 + 4);
    t64 = (t51 + 4);
    t65 = (t59 + 4);
    t66 = *((unsigned int *)t63);
    t67 = *((unsigned int *)t64);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t69 = *((unsigned int *)t65);
    t70 = (t69 != 0);
    if (t70 == 1)
        goto LAB125;

LAB126:
LAB127:    goto LAB116;

LAB119:    t50 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t50) = 1;
    goto LAB120;

LAB121:    *((unsigned int *)t51) = 1;
    goto LAB124;

LAB123:    t58 = (t51 + 4);
    *((unsigned int *)t51) = 1;
    *((unsigned int *)t58) = 1;
    goto LAB124;

LAB125:    t71 = *((unsigned int *)t59);
    t72 = *((unsigned int *)t65);
    *((unsigned int *)t59) = (t71 | t72);
    t73 = (t21 + 4);
    t74 = (t51 + 4);
    t75 = *((unsigned int *)t21);
    t76 = (~(t75));
    t77 = *((unsigned int *)t73);
    t78 = (~(t77));
    t79 = *((unsigned int *)t51);
    t80 = (~(t79));
    t81 = *((unsigned int *)t74);
    t82 = (~(t81));
    t83 = (t76 & t78);
    t84 = (t80 & t82);
    t85 = (~(t83));
    t86 = (~(t84));
    t87 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t87 & t85);
    t88 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t88 & t86);
    t89 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t89 & t85);
    t90 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t90 & t86);
    goto LAB127;

LAB128:    xsi_set_current_line(83, ng34);
    t97 = (t0 + 4456);
    t98 = (t97 + 56U);
    t99 = *((char **)t98);
    t100 = ((char*)((ng31)));
    memset(t101, 0, 8);
    xsi_vlog_unsigned_add(t101, 32, t99, 5, t100, 32);
    t102 = (t0 + 4456);
    xsi_vlogvar_assign_value(t102, t101, 0, 0, 5);
    goto LAB130;

LAB135:;
LAB137:    t37 = (t0 + 7296U);
    *((char **)t37) = &&LAB134;
    goto LAB1;

LAB138:    xsi_set_current_line(92, ng34);
    t3 = ((char*)((ng30)));
    t4 = (t0 + 3816);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(94, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng31)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t8 = *((unsigned int *)t3);
    t9 = *((unsigned int *)t2);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t4);
    t12 = *((unsigned int *)t6);
    t13 = (t11 ^ t12);
    t14 = (t10 | t13);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t6);
    t17 = (t15 | t16);
    t18 = (~(t17));
    t19 = (t14 & t18);
    if (t19 != 0)
        goto LAB142;

LAB139:    if (t17 != 0)
        goto LAB141;

LAB140:    *((unsigned int *)t5) = 1;

LAB142:    t20 = (t5 + 4);
    t23 = *((unsigned int *)t20);
    t24 = (~(t23));
    t25 = *((unsigned int *)t5);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB143;

LAB144:    xsi_set_current_line(96, ng34);

LAB146:    xsi_set_current_line(97, ng34);
    xsi_vlogfile_write(1, 0, 0, ng42, 1, t0);
    xsi_set_current_line(98, ng34);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng11)));
    t7 = ((char*)((ng36)));
    t20 = (t0 + 7104);
    t22 = (t0 + 1712);
    t28 = xsi_create_subprogram_invocation(t20, 0, t0, t22, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t22, t28);
    t29 = (t0 + 5416);
    xsi_vlogvar_assign_value(t29, t5, 0, 0, 8);
    t33 = (t0 + 5576);
    xsi_vlogvar_assign_value(t33, t6, 0, 0, 8);
    t34 = (t0 + 5736);
    t36 = ((char*)((ng36)));
    t103 = xsi_vlog_convert_to_real(t36, 32, 1);
    xsi_vlogvar_assign_value_double(t34, t103, 0);

LAB149:    t37 = (t0 + 7200);
    t50 = *((char **)t37);
    t52 = (t50 + 80U);
    t58 = *((char **)t52);
    t63 = (t58 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t73 = *((char **)t65);
    t83 = ((int  (*)(char *, char *))t73)(t0, t50);

LAB151:    if (t83 != 0)
        goto LAB152;

LAB147:    t50 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t50);

LAB148:    t74 = (t0 + 7200);
    t91 = *((char **)t74);
    t74 = (t0 + 1712);
    t97 = (t0 + 7104);
    t98 = 0;
    xsi_delete_subprogram_invocation(t74, t91, t0, t97, t98);

LAB145:    xsi_set_current_line(101, ng34);
    t2 = (t0 + 2776U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng31)));
    memset(t5, 0, 8);
    t4 = (t3 + 4);
    t6 = (t2 + 4);
    t8 = *((unsigned int *)t3);
    t9 = *((unsigned int *)t2);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t4);
    t12 = *((unsigned int *)t6);
    t13 = (t11 ^ t12);
    t14 = (t10 | t13);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t6);
    t17 = (t15 | t16);
    t18 = (~(t17));
    t19 = (t14 & t18);
    if (t19 != 0)
        goto LAB156;

LAB153:    if (t17 != 0)
        goto LAB155;

LAB154:    *((unsigned int *)t5) = 1;

LAB156:    memset(t21, 0, 8);
    t20 = (t5 + 4);
    t23 = *((unsigned int *)t20);
    t24 = (~(t23));
    t25 = *((unsigned int *)t5);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB157;

LAB158:    if (*((unsigned int *)t20) != 0)
        goto LAB159;

LAB160:    t28 = (t21 + 4);
    t30 = *((unsigned int *)t21);
    t31 = *((unsigned int *)t28);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB161;

LAB162:    memcpy(t59, t21, 8);

LAB163:    t74 = (t59 + 4);
    t92 = *((unsigned int *)t74);
    t93 = (~(t92));
    t94 = *((unsigned int *)t59);
    t95 = (t94 & t93);
    t96 = (t95 != 0);
    if (t96 > 0)
        goto LAB175;

LAB176:    xsi_set_current_line(103, ng34);

LAB178:    xsi_set_current_line(104, ng34);
    xsi_vlogfile_write(1, 0, 0, ng43, 1, t0);
    xsi_set_current_line(105, ng34);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng11)));
    t7 = ((char*)((ng36)));
    t20 = (t0 + 7104);
    t22 = (t0 + 1712);
    t28 = xsi_create_subprogram_invocation(t20, 0, t0, t22, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t22, t28);
    t29 = (t0 + 5416);
    xsi_vlogvar_assign_value(t29, t5, 0, 0, 8);
    t33 = (t0 + 5576);
    xsi_vlogvar_assign_value(t33, t6, 0, 0, 8);
    t34 = (t0 + 5736);
    t36 = ((char*)((ng36)));
    t103 = xsi_vlog_convert_to_real(t36, 32, 1);
    xsi_vlogvar_assign_value_double(t34, t103, 0);

LAB181:    t37 = (t0 + 7200);
    t50 = *((char **)t37);
    t52 = (t50 + 80U);
    t58 = *((char **)t52);
    t63 = (t58 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t73 = *((char **)t65);
    t83 = ((int  (*)(char *, char *))t73)(t0, t50);

LAB183:    if (t83 != 0)
        goto LAB184;

LAB179:    t50 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t50);

LAB180:    t74 = (t0 + 7200);
    t91 = *((char **)t74);
    t74 = (t0 + 1712);
    t97 = (t0 + 7104);
    t98 = 0;
    xsi_delete_subprogram_invocation(t74, t91, t0, t97, t98);

LAB177:    xsi_set_current_line(108, ng34);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memcpy(t5, t4, 8);
    t6 = ((char*)((ng11)));
    t7 = ((char*)((ng36)));
    t20 = (t0 + 7104);
    t22 = (t0 + 1280);
    t28 = xsi_create_subprogram_invocation(t20, 0, t0, t22, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t22, t28);
    t29 = (t0 + 4776);
    xsi_vlogvar_assign_value(t29, t5, 0, 0, 8);
    t33 = (t0 + 4936);
    xsi_vlogvar_assign_value(t33, t6, 0, 0, 8);
    t34 = (t0 + 5096);
    t36 = ((char*)((ng36)));
    t103 = xsi_vlog_convert_to_real(t36, 32, 1);
    xsi_vlogvar_assign_value_double(t34, t103, 0);

LAB187:    t37 = (t0 + 7200);
    t50 = *((char **)t37);
    t52 = (t50 + 80U);
    t58 = *((char **)t52);
    t63 = (t58 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t73 = *((char **)t65);
    t83 = ((int  (*)(char *, char *))t73)(t0, t50);

LAB189:    if (t83 != 0)
        goto LAB190;

LAB185:    t50 = (t0 + 1280);
    xsi_vlog_subprogram_popinvocation(t50);

LAB186:    t74 = (t0 + 7200);
    t91 = *((char **)t74);
    t74 = (t0 + 1280);
    t97 = (t0 + 7104);
    t98 = 0;
    xsi_delete_subprogram_invocation(t74, t91, t0, t97, t98);
    goto LAB1;

LAB141:    t7 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB142;

LAB143:    xsi_set_current_line(95, ng34);
    t22 = (t0 + 4456);
    t28 = (t22 + 56U);
    t29 = *((char **)t28);
    t33 = ((char*)((ng31)));
    memset(t21, 0, 8);
    xsi_vlog_unsigned_add(t21, 32, t29, 5, t33, 32);
    t34 = (t0 + 4456);
    xsi_vlogvar_assign_value(t34, t21, 0, 0, 5);
    goto LAB145;

LAB150:;
LAB152:    t37 = (t0 + 7296U);
    *((char **)t37) = &&LAB149;
    goto LAB1;

LAB155:    t7 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB156;

LAB157:    *((unsigned int *)t21) = 1;
    goto LAB160;

LAB159:    t22 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB160;

LAB161:    t29 = (t0 + 3096U);
    t33 = *((char **)t29);
    t29 = ((char*)((ng36)));
    memset(t35, 0, 8);
    t34 = (t33 + 4);
    t36 = (t29 + 4);
    t38 = *((unsigned int *)t33);
    t39 = *((unsigned int *)t29);
    t40 = (t38 ^ t39);
    t41 = *((unsigned int *)t34);
    t42 = *((unsigned int *)t36);
    t43 = (t41 ^ t42);
    t44 = (t40 | t43);
    t45 = *((unsigned int *)t34);
    t46 = *((unsigned int *)t36);
    t47 = (t45 | t46);
    t48 = (~(t47));
    t49 = (t44 & t48);
    if (t49 != 0)
        goto LAB167;

LAB164:    if (t47 != 0)
        goto LAB166;

LAB165:    *((unsigned int *)t35) = 1;

LAB167:    memset(t51, 0, 8);
    t50 = (t35 + 4);
    t53 = *((unsigned int *)t50);
    t54 = (~(t53));
    t55 = *((unsigned int *)t35);
    t56 = (t55 & t54);
    t57 = (t56 & 1U);
    if (t57 != 0)
        goto LAB168;

LAB169:    if (*((unsigned int *)t50) != 0)
        goto LAB170;

LAB171:    t60 = *((unsigned int *)t21);
    t61 = *((unsigned int *)t51);
    t62 = (t60 & t61);
    *((unsigned int *)t59) = t62;
    t58 = (t21 + 4);
    t63 = (t51 + 4);
    t64 = (t59 + 4);
    t66 = *((unsigned int *)t58);
    t67 = *((unsigned int *)t63);
    t68 = (t66 | t67);
    *((unsigned int *)t64) = t68;
    t69 = *((unsigned int *)t64);
    t70 = (t69 != 0);
    if (t70 == 1)
        goto LAB172;

LAB173:
LAB174:    goto LAB163;

LAB166:    t37 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t37) = 1;
    goto LAB167;

LAB168:    *((unsigned int *)t51) = 1;
    goto LAB171;

LAB170:    t52 = (t51 + 4);
    *((unsigned int *)t51) = 1;
    *((unsigned int *)t52) = 1;
    goto LAB171;

LAB172:    t71 = *((unsigned int *)t59);
    t72 = *((unsigned int *)t64);
    *((unsigned int *)t59) = (t71 | t72);
    t65 = (t21 + 4);
    t73 = (t51 + 4);
    t75 = *((unsigned int *)t21);
    t76 = (~(t75));
    t77 = *((unsigned int *)t65);
    t78 = (~(t77));
    t79 = *((unsigned int *)t51);
    t80 = (~(t79));
    t81 = *((unsigned int *)t73);
    t82 = (~(t81));
    t83 = (t76 & t78);
    t84 = (t80 & t82);
    t85 = (~(t83));
    t86 = (~(t84));
    t87 = *((unsigned int *)t64);
    *((unsigned int *)t64) = (t87 & t85);
    t88 = *((unsigned int *)t64);
    *((unsigned int *)t64) = (t88 & t86);
    t89 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t89 & t85);
    t90 = *((unsigned int *)t59);
    *((unsigned int *)t59) = (t90 & t86);
    goto LAB174;

LAB175:    xsi_set_current_line(102, ng34);
    t91 = (t0 + 4456);
    t97 = (t91 + 56U);
    t98 = *((char **)t97);
    t99 = ((char*)((ng31)));
    memset(t101, 0, 8);
    xsi_vlog_unsigned_add(t101, 32, t98, 5, t99, 32);
    t100 = (t0 + 4456);
    xsi_vlogvar_assign_value(t100, t101, 0, 0, 5);
    goto LAB177;

LAB182:;
LAB184:    t37 = (t0 + 7296U);
    *((char **)t37) = &&LAB181;
    goto LAB1;

LAB188:;
LAB190:    t37 = (t0 + 7296U);
    *((char **)t37) = &&LAB187;
    goto LAB1;

}

static void Always_110_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 7544U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(110, ng34);

LAB4:    xsi_set_current_line(111, ng34);
    t2 = (t0 + 7352);
    xsi_process_wait(t2, 1000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(111, ng34);
    t4 = (t0 + 4296);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t7) == 0)
        goto LAB6;

LAB8:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB9:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB11;

LAB10:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 4296);
    xsi_vlogvar_assign_value(t24, t3, 0, 0, 1);
    goto LAB2;

LAB6:    *((unsigned int *)t3) = 1;
    goto LAB9;

LAB11:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB10;

}


extern void work_m_00000000004218563013_3098922889_init()
{
	static char *pe[] = {(void *)Initial_36_0,(void *)Always_110_1};
	static char *se[] = {(void *)sp_exp_output,(void *)sp_succ_exit,(void *)sp_err_exit,(void *)sp_show_LEDs};
	xsi_register_didat("work_m_00000000004218563013_3098922889", "isim/test_ex4_isim_beh.exe.sim/work/m_00000000004218563013_3098922889.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
	xsi_register_subprogram_init(1, (void *)exp_output_varinit);
}
